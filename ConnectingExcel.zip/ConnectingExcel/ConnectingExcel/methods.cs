﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Office.Interop.Excel;

namespace ConnectingExcel
{
    internal class methods
    {
        Random rnd = new Random();

        public int[] getCol1Nums(int sn, int en, int incn)
        {
            int n = ((en - sn) / incn);

            int[] ints = new int[n];

            for (int i = 0; i < ints.Length; i++)
            {
                ints[i] = sn + (incn * i);
            }

            if ((en - sn) % incn == 0)
            {
                return ints;
            }

            else
            {
                ints = new int[0];
                return ints;
            }

        }

        public int[] getCol2Nums(int sn, int en, int incn)
        {
            int n = ((en - sn) / incn);

            int[] ints = new int[n];

            for (int i = 0; i < ints.Length; i++)
            {
                ints[i] = rnd.Next(0, 50);
            }

            return ints;
        }

        public int[] getCol3Nums(int sn, int en, int incn)
        {
            int n = ((en - sn) / incn);

            int[] ints = new int[n];

            for (int i = 0; i < ints.Length; i++)
            {
                ints[i] = rnd.Next(0, 50);
            }

            return ints;
        }
    }
}
