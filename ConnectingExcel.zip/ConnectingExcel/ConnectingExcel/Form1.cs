using Microsoft.Office.Interop.Excel;
using Microsoft.VisualBasic.ApplicationServices;
using Excel = Microsoft.Office.Interop.Excel;
namespace ConnectingExcel
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            //set errorlabel to be invisible
            ErrorLabel.Visible = false;
            
            //read in the user input, make sure they are all ints.
            Int32.TryParse(StartTxt.Text, out int startNum);
            Int32.TryParse(EndTxt.Text, out int endNum);
            Int32.TryParse(IncrementTxt.Text, out int incrementNum);

            //instantiation of methods I call ms, then use that to get int arrays from methods class using different methods.
            methods ms = new methods();
            int[] c1nums = ms.getCol1Nums(startNum, endNum, incrementNum);
            int[] c2nums = ms.getCol2Nums(startNum, endNum, incrementNum);
            int[] c3nums = ms.getCol3Nums(startNum, endNum, incrementNum);

            //if the user input is not properly divisiable getCol1Nums will return an empty array, and then this label will become visible.
            if (c1nums.Length == 0)
            {
                ErrorLabel.Visible = true;
                return;
            }

            //if it is properly divisible:
            else
            {
                //new excel app
                Excel.Application excel = new Excel.Application();
                excel.Visible = true;

                // Create a new workbook
                Excel.Workbook workbook = excel.Workbooks.Add();

                // Create new sheet and name it data, create it at the first index so it is the first sheet
                Excel.Worksheet worksheet = (Excel.Worksheet)workbook.Worksheets[1];
                worksheet.Name = "Data";

                //Set the names of the columns
                worksheet.Cells[1, 1].Value = "Increments";
                worksheet.Cells[1, 2].Value = "Set #1";
                worksheet.Cells[1, 3].Value = "Set #2";

                //set size of column A so "Increments" will fit
                worksheet.Columns["A"].ColumnWidth = 15;

                //Fill the cells with int arrays from earlier.
                for (int i = 0; i < c1nums.Length; i++)
                {
                    worksheet.Cells[i + 2, 1].Value = c1nums[i];
                    worksheet.Cells[i + 2, 2].Value = c2nums[i];
                    worksheet.Cells[i + 2, 3].Value = c3nums[i];
                }

                // Create a chart object
                Excel.ChartObjects charts = (Excel.ChartObjects)worksheet.ChartObjects(Type.Missing);
                Excel.ChartObject chartObj = charts.Add(200, 20, 450, 300);

                // Set the chart type
                Excel.Chart chart = chartObj.Chart;
                chart.ChartType = Excel.XlChartType.xlXYScatterLines;

                // Set the chart data range
                Excel.Range chartRange = worksheet.Range["A1:C" + c2nums.Length + 1];
                chart.SetSourceData(chartRange);

                //create title
                chart.HasTitle = true;
                chart.ChartTitle.Text = "My graph I named this";

                //create legend
                chart.HasLegend = true;
                chart.Legend.Position = Excel.XlLegendPosition.xlLegendPositionBottom;

                //name xAxis
                Excel.Axis xAxis = (Excel.Axis)chart.Axes(Excel.XlAxisType.xlCategory);
                xAxis.HasTitle = true;
                xAxis.AxisTitle.Text = "Increment";

                //name yAxis
                Excel.Axis yAxis = (Excel.Axis)chart.Axes(Excel.XlAxisType.xlValue);
                yAxis.HasTitle = true;
                yAxis.AxisTitle.Text = "Numbers";

                //name yAxis
                xAxis.MinimumScale = startNum;  // Custom starting point for X-axis
                yAxis.MinimumScale = 0;

                //create a second worksheet, name it, fill the first cell with the string, change the size of the column to fit it.
                Excel.Worksheet worksheet2 = (Excel.Worksheet)workbook.Worksheets.Add();
                worksheet2.Name = "Additional";
                worksheet2.Cells[1, 1] = "This is my second sheet I can now work with";
                worksheet2.Columns["A"].ColumnWidth = 40;

                //release all objects (unsure of what this really does, everyone online recommended you do it, I'm assuming its like a task manager / resource
                //type of deal
                ReleaseObject(chartRange);
                ReleaseObject(yAxis);
                ReleaseObject(xAxis);
                ReleaseObject(chart);
                ReleaseObject(chartObj);
                ReleaseObject(charts);
                ReleaseObject(worksheet2);
                ReleaseObject(worksheet);
                ReleaseObject(workbook);
                ReleaseObject(excel);
            }
        }

        private static void ReleaseObject(object obj)
        {
            try
            {
                System.Runtime.InteropServices.Marshal.ReleaseComObject(obj);
            }
            catch (Exception ex)
            {
                Console.WriteLine("Error releasing object: " + ex.Message);
            }
            finally
            {
                obj = null;
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}