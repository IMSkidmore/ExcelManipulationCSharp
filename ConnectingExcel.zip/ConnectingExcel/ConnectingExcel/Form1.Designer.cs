﻿namespace ConnectingExcel
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            StartTxt = new TextBox();
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            EndTxt = new TextBox();
            IncrementTxt = new TextBox();
            button1 = new Button();
            ErrorLabel = new Label();
            SuspendLayout();
            // 
            // StartTxt
            // 
            StartTxt.Location = new Point(130, 32);
            StartTxt.Name = "StartTxt";
            StartTxt.Size = new Size(125, 27);
            StartTxt.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(24, 28);
            label1.Name = "label1";
            label1.Size = new Size(82, 28);
            label1.TabIndex = 1;
            label1.Text = "Start At:";
            label1.Click += label1_Click;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(24, 99);
            label2.Name = "label2";
            label2.Size = new Size(74, 28);
            label2.TabIndex = 2;
            label2.Text = "End At:";
            label2.Click += label2_Click;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(24, 177);
            label3.Name = "label3";
            label3.Size = new Size(103, 28);
            label3.TabIndex = 3;
            label3.Text = "Increment:";
            label3.Click += label3_Click;
            // 
            // EndTxt
            // 
            EndTxt.Location = new Point(130, 103);
            EndTxt.Name = "EndTxt";
            EndTxt.Size = new Size(125, 27);
            EndTxt.TabIndex = 4;
            // 
            // IncrementTxt
            // 
            IncrementTxt.Location = new Point(130, 181);
            IncrementTxt.Name = "IncrementTxt";
            IncrementTxt.Size = new Size(125, 27);
            IncrementTxt.TabIndex = 5;
            // 
            // button1
            // 
            button1.Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(156, 247);
            button1.Name = "button1";
            button1.Size = new Size(99, 46);
            button1.TabIndex = 6;
            button1.Text = "Create";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // ErrorLabel
            // 
            ErrorLabel.AutoSize = true;
            ErrorLabel.Font = new Font("Segoe UI", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            ErrorLabel.ForeColor = Color.Firebrick;
            ErrorLabel.Location = new Point(24, 325);
            ErrorLabel.Name = "ErrorLabel";
            ErrorLabel.Size = new Size(429, 31);
            ErrorLabel.TabIndex = 7;
            ErrorLabel.Text = "Error - Numbers are not cleanly divisible.";
            ErrorLabel.Visible = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = SystemColors.ControlLight;
            ClientSize = new Size(800, 450);
            Controls.Add(ErrorLabel);
            Controls.Add(button1);
            Controls.Add(IncrementTxt);
            Controls.Add(EndTxt);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Controls.Add(StartTxt);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private TextBox StartTxt;
        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox EndTxt;
        private TextBox IncrementTxt;
        private Button button1;
        private Label ErrorLabel;
    }
}